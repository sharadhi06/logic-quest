// pl_reg_em.v - Execute to Memory Pipeline Register

module pl_reg_em (
    input clk,
    input clr,

    // Data from Execute stage
    input [31:0] ALUResultE,
    input [31:0] WriteDataE,
    input [31:0] PCPlus4E,
    input [31:0] AuiPCE,
    input [31:0] PCE,
    input [4:0] RdE,

    // Control signals from Execute stage
    input RegWriteE,
    input MemWriteE,
    input [1:0] ResultSrcE,
    input [2:0] funct3E,

    // Data to Memory stage
    output reg [31:0] ALUResultM,
    output reg [31:0] WriteDataM,
    output reg [31:0] PCPlus4M,
    output reg [31:0] AuiPCM,
    output reg [31:0] PCM,
    output reg [4:0] RdM,

    // Control signals to Memory stage
    output reg RegWriteM,
    output reg MemWriteM,
    output reg [1:0] ResultSrcM,
    output reg [2:0] funct3M
);

always @(posedge clk) begin

    if (clr) begin
        // Clear the Memory-stage pipeline register
        ALUResultM <= 0;
        WriteDataM <= 0;
        PCPlus4M <= 0;
        AuiPCM <= 0;
        PCM <= 0;
        RdM <= 0;

        RegWriteM <= 0;
        MemWriteM <= 0;
        ResultSrcM <= 0;
        funct3M <= 0;
    end

    else begin
        // Transfer Execute-stage values to Memory stage
        ALUResultM <= ALUResultE;
        WriteDataM <= WriteDataE;
        PCPlus4M <= PCPlus4E;
        AuiPCM <= AuiPCE;
        PCM <= PCE;
        RdM <= RdE;

        RegWriteM <= RegWriteE;
        MemWriteM <= MemWriteE;
        ResultSrcM <= ResultSrcE;
        funct3M <= funct3E;
    end

end

endmodule
