// riscv_cpu.v - 5-Stage Pipelined RISC-V CPU

module riscv_cpu (
    input         clk, reset,
    output [31:0] PC,
    input  [31:0] Instr,
    output        MemWrite,
    output [31:0] Mem_WrAddr, Mem_WrData,
    input  [31:0] ReadData,
    output [31:0] Result,
    output [2:0]  funct3,
    output [31:0] PCW, ALUResultW, WriteDataW
);

// Decode-stage control signals
wire ALUSrcD, RegWriteD, BranchD, JumpD, JalrD, AUIPCD;
wire MemWriteD;

wire [1:0] ResultSrcD;
wire [2:0] ImmSrcD;
wire [3:0] ALUControlD;

// Instruction in Decode stage
wire [31:0] InstrD;

// Memory-stage signals
wire MemWriteM;
wire [2:0] funct3M;

// Controller - decodes instruction in Decode stage
controller c (
    .op(InstrD[6:0]),
    .funct3(InstrD[14:12]),
    .funct7b5(InstrD[30]),

    .ResultSrc(ResultSrcD),
    .MemWrite(MemWriteD),
    .ALUSrc(ALUSrcD),
    .RegWrite(RegWriteD),
    .Branch(BranchD),
    .Jump(JumpD),
    .Jalr(JalrD),
    .AUIPC(AUIPCD),

    .ImmSrc(ImmSrcD),
    .ALUControl(ALUControlD)
);

// Pipelined Datapath
datapath dp (
    .clk(clk),
    .reset(reset),

    .InstrF(Instr),
    .PCF(PC),
    .InstrD(InstrD),

    .ResultSrcD(ResultSrcD),
    .ALUSrcD(ALUSrcD),
    .RegWriteD(RegWriteD),
    .MemWriteD(MemWriteD),

    .ImmSrcD(ImmSrcD),
    .ALUControlD(ALUControlD),

    .BranchD(BranchD),
    .JumpD(JumpD),
    .JalrD(JalrD),
    .AUIPCD(AUIPCD),

    .ReadDataM(ReadData),

    .Mem_WrAddr(Mem_WrAddr),
    .Mem_WrData(Mem_WrData),
    .MemWriteM(MemWriteM),
    .funct3M(funct3M),

    .ResultW(Result),
    .PCW(PCW),
    .ALUResultW(ALUResultW),
    .WriteDataW(WriteDataW)
);

// Memory-stage outputs
assign MemWrite = MemWriteM;
assign funct3  = funct3M;

endmodule
