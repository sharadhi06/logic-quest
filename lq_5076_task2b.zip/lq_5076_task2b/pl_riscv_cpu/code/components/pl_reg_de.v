// pl_reg_de.v - Decode to Execute Pipeline Register

module pl_reg_de (
    input clk,
    input reset,
    input clr,


    // Data from Decode stage
    input [31:0] RD1D, RD2D,
    input [31:0] PCD, PCPlus4D, ImmExtD,
    input [4:0] Rs1D, Rs2D, RdD,

    // Control signals from Decode stage
    input RegWriteD, MemWriteD, ALUSrcD,
    input BranchD, JumpD, JalrD, AUIPCD,
    input [1:0] ResultSrcD,
    input [3:0] ALUControlD,
    input [2:0] funct3D,

    // Data to Execute stage
    output reg [31:0] RD1E, RD2E,
    output reg [31:0] PCE, PCPlus4E, ImmExtE,
    output reg [4:0] Rs1E, Rs2E, RdE,

    // Control signals to Execute stage
    output reg RegWriteE, MemWriteE, ALUSrcE,
    output reg BranchE, JumpE, JalrE, AUIPCE,
    output reg [1:0] ResultSrcE,
    output reg [3:0] ALUControlE,
    output reg [2:0] funct3E
);

always @(posedge clk) begin

    if (reset || clr) begin
        // Insert a bubble into the Execute stage
        RD1E <= 0;
        RD2E <= 0;
        PCE <= 0;
        PCPlus4E <= 0;
        ImmExtE <= 0;

        Rs1E <= 0;
        Rs2E <= 0;
        RdE <= 0;

        RegWriteE <= 0;
        MemWriteE <= 0;
        ALUSrcE <= 0;
        BranchE <= 0;
        JumpE <= 0;
        JalrE <= 0;
        AUIPCE <= 0;

        ResultSrcE <= 0;
        ALUControlE <= 0;
        funct3E <= 0;
    end

    else begin
        // Transfer Decode-stage values to Execute stage
        RD1E <= RD1D;
        RD2E <= RD2D;
        PCE <= PCD;
        PCPlus4E <= PCPlus4D;
        ImmExtE <= ImmExtD;

        Rs1E <= Rs1D;
        Rs2E <= Rs2D;
        RdE <= RdD;

        RegWriteE <= RegWriteD;
        MemWriteE <= MemWriteD;
        ALUSrcE <= ALUSrcD;
        BranchE <= BranchD;
        JumpE <= JumpD;
        JalrE <= JalrD;
        AUIPCE <= AUIPCD;

        ResultSrcE <= ResultSrcD;
        ALUControlE <= ALUControlD;
        funct3E <= funct3D;
    end

end

endmodule
