// reg_file.v - Optimized RISC-V Register File
// 32 registers, 32 bits each
// Two asynchronous read ports
// One falling-edge write port

module reg_file #(parameter DATA_WIDTH = 32) (
    input clk,
    input wr_en,

    input [4:0] rd_addr1, rd_addr2, wr_addr,
    input [DATA_WIDTH-1:0] wr_data,

    output reg [DATA_WIDTH-1:0] rd_data1, rd_data2
);

reg [DATA_WIDTH-1:0] reg_file_arr [0:31];

wire [31:0] read_sel1;
wire [31:0] read_sel2;

genvar g;

generate
    for (g = 0; g < 32; g = g + 1) begin : decode
        assign read_sel1[g] = (rd_addr1 == g);
        assign read_sel2[g] = (rd_addr2 == g);
    end
endgenerate

// Falling-edge register write
always @(negedge clk) begin
    if (wr_en && (wr_addr != 5'd0))
        reg_file_arr[wr_addr] <= wr_data;
end

// One-hot read selection
integer i;

always @(*) begin
    rd_data1 = {DATA_WIDTH{1'b0}};
    rd_data2 = {DATA_WIDTH{1'b0}};

    for (i = 1; i < 32; i = i + 1) begin
        rd_data1 = rd_data1 |
                   (reg_file_arr[i] &
                    {DATA_WIDTH{read_sel1[i]}});

        rd_data2 = rd_data2 |
                   (reg_file_arr[i] &
                    {DATA_WIDTH{read_sel2[i]}});
    end
end

endmodule
