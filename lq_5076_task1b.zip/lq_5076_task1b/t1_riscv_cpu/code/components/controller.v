
// controller.v - controller for RISC-V CPU

module controller (
    input [6:0]  op,
    input [2:0]  funct3,
    input        funct7b5,
    input        Zero,
    output       [1:0] ResultSrc,
    output       MemWrite,
    output       [1:0] PCSrc,  
	 output ALUSrc,
    output       RegWrite, Jump, AUIPC,
    output [2:0] ImmSrc,
    output [2:0] ALUControl
);

wire [1:0] ALUOp;
wire       Branch, JALR;

main_decoder    md (op, ResultSrc, MemWrite, Branch,
                    ALUSrc, RegWrite, Jump, AUIPC, JALR, ImmSrc, ALUOp);

alu_decoder     ad (op[5], funct3, funct7b5, ALUOp, ALUControl);

// for jump and branch
assign PCSrc = JALR ? 2'b10 :
               ((Branch & Zero) | Jump) ? 2'b01 :
               2'b00;

endmodule

