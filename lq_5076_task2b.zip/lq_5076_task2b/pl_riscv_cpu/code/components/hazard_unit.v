// hazard_unit.v - Hazard Detection and Forwarding Unit

module hazard_unit (
    input [4:0] Rs1D, Rs2D,
    input [4:0] Rs1E, Rs2E,
    input [4:0] RdE, RdM, RdW,

    input RegWriteM, RegWriteW,
    input [1:0] ResultSrcE,
    input PCSrcE,

    output reg [1:0] ForwardAE, ForwardBE,
    output StallF, StallD,
    output FlushD, FlushE
);

// Forwarding logic
always @(*) begin

    ForwardAE = 2'b00;
    ForwardBE = 2'b00;

    // Forward operand A from Memory stage
    if ((Rs1E != 0) && (Rs1E == RdM) && RegWriteM)
        ForwardAE = 2'b10;

    // Forward operand A from Writeback stage
    else if ((Rs1E != 0) && (Rs1E == RdW) && RegWriteW)
        ForwardAE = 2'b01;

    // Forward operand B from Memory stage
    if ((Rs2E != 0) && (Rs2E == RdM) && RegWriteM)
        ForwardBE = 2'b10;

    // Forward operand B from Writeback stage
    else if ((Rs2E != 0) && (Rs2E == RdW) && RegWriteW)
        ForwardBE = 2'b01;

end

// Load-use hazard detection
wire lwStall;

assign lwStall = (ResultSrcE == 2'b01) &&
                 ((Rs1D == RdE) || (Rs2D == RdE)) &&
                 (RdE != 0);

// Stall Fetch and Decode stages
assign StallF = lwStall;
assign StallD = lwStall;

// Flush incorrect instructions
assign FlushD = PCSrcE;

// Insert bubble into Execute stage
assign FlushE = lwStall | PCSrcE;

endmodule
