// branching_unit.v - RISC-V Branch Decision Unit

module branching_unit (
    input [2:0] funct3,
    input Zero,
    input ALUR31,
    output reg Branch
);

always @(*) begin
    case (funct3)

        3'b000: Branch = Zero;       // BEQ
        3'b001: Branch = !Zero;      // BNE

        3'b100: Branch = ALUR31;     // BLT
        3'b101: Branch = !ALUR31;    // BGE

        3'b110: Branch = ALUR31;     // BLTU
        3'b111: Branch = !ALUR31;    // BGEU

        default: Branch = 1'b0;

    endcase
end

endmodule
