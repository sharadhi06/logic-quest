
// controller.v - controller for RISC-V CPU

module controller (
    input [6:0]  op,
    input [2:0]  funct3,
    input        funct7b5,
    input        Zero,
    input LT, LTU,
    output       [1:0] ResultSrc,
    output       MemWrite,
    output       [1:0] PCSrc,  
	 output ALUSrc,
    output       RegWrite, Jump, AUIPC,
    output [2:0] ImmSrc,
    output [3:0] ALUControl
);

wire [1:0] ALUOp;
wire       Branch, JALR;
reg BranchTaken;

always @(*) begin
    case (funct3)
        3'b000: BranchTaken = Zero;   // BEQ
        3'b001: BranchTaken = ~Zero;  // BNE
        3'b100: BranchTaken = LT;     // BLT
        3'b101: BranchTaken = ~LT;    // BGE
        3'b110: BranchTaken = LTU;    // BLTU
        3'b111: BranchTaken = ~LTU;   // BGEU
        default: BranchTaken = 1'b0;
    endcase
end

main_decoder    md (op, ResultSrc, MemWrite, Branch,
                    ALUSrc, RegWrite, Jump, AUIPC, JALR, ImmSrc, ALUOp);

alu_decoder     ad (op[5], funct3, funct7b5, ALUOp, ALUControl);

// for jump and branch
assign PCSrc = JALR ? 2'b10 :
               ((Branch & BranchTaken) | Jump) ? 2'b01 :
               2'b00;

endmodule

