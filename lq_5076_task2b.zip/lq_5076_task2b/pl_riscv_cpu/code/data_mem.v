// Experimental data memory: four byte-write banks, clocked read on falling edge.
// Designed to keep the existing EX/MEM -> MEM/WB positive-edge timing.
// Not yet verified in Quartus/ModelSim.
module data_mem #(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 32,
    parameter MEM_SIZE = 64
)(
    input clk, wr_en,
    input [2:0] funct3,
    input [ADDR_WIDTH-1:0] wr_addr, wr_data,
    output reg [DATA_WIDTH-1:0] rd_data_mem
);

reg [7:0] bank0 [0:MEM_SIZE-1];
reg [7:0] bank1 [0:MEM_SIZE-1];
reg [7:0] bank2 [0:MEM_SIZE-1];
reg [7:0] bank3 [0:MEM_SIZE-1];

wire [5:0] word_addr = wr_addr[7:2];
reg [7:0] r0, r1, r2, r3;

// Same positive-edge write behavior as the existing design.
always @(posedge clk) begin
    if (wr_en) begin
        case (funct3)
            3'b000: begin
                case (wr_addr[1:0])
                    2'b00: bank0[word_addr] <= wr_data[7:0];
                    2'b01: bank1[word_addr] <= wr_data[7:0];
                    2'b10: bank2[word_addr] <= wr_data[7:0];
                    2'b11: bank3[word_addr] <= wr_data[7:0];
                endcase
            end
            3'b001: begin
                if (!wr_addr[1]) begin
                    bank0[word_addr] <= wr_data[7:0];
                    bank1[word_addr] <= wr_data[15:8];
                end else begin
                    bank2[word_addr] <= wr_data[7:0];
                    bank3[word_addr] <= wr_data[15:8];
                end
            end
            3'b010: begin
                bank0[word_addr] <= wr_data[7:0];
                bank1[word_addr] <= wr_data[15:8];
                bank2[word_addr] <= wr_data[23:16];
                bank3[word_addr] <= wr_data[31:24];
            end
        endcase
    end
end

// Clocked bank reads: address from EX/MEM is valid after rising edge;
// falling-edge reads complete before the next rising-edge MEM/WB capture.
always @(negedge clk) begin
    r0 <= bank0[word_addr];
    r1 <= bank1[word_addr];
    r2 <= bank2[word_addr];
    r3 <= bank3[word_addr];
end

wire [31:0] word_data = {r3, r2, r1, r0};
wire [7:0] selected_byte =
    (wr_addr[1:0] == 2'b00) ? r0 :
    (wr_addr[1:0] == 2'b01) ? r1 :
    (wr_addr[1:0] == 2'b10) ? r2 : r3;
wire [15:0] selected_halfword = wr_addr[1] ? {r3,r2} : {r1,r0};

always @(*) begin
    case (funct3)
        3'b000: rd_data_mem = {{24{selected_byte[7]}}, selected_byte};
        3'b001: rd_data_mem = {{16{selected_halfword[15]}}, selected_halfword};
        3'b010: rd_data_mem = word_data;
        3'b100: rd_data_mem = {24'b0, selected_byte};
        3'b101: rd_data_mem = {16'b0, selected_halfword};
        default: rd_data_mem = 32'bx;
    endcase
end
endmodule
