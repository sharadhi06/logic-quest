// alu.v - Optimized RISC-V ALU
// Shared ADD/SUB hardware

module alu #(parameter WIDTH = 32) (
    input [WIDTH-1:0] a, b,
    input [3:0] alu_ctrl,
    output reg [WIDTH-1:0] alu_out,
    output zero
);

// Shared adder/subtractor
wire subtract;

assign subtract =
    (alu_ctrl == 4'b0001) ||
    (alu_ctrl == 4'b0101) ||
    (alu_ctrl == 4'b0111);

wire [WIDTH-1:0] b_modified;
wire [WIDTH-1:0] arithmetic_result;

assign b_modified = b ^ {WIDTH{subtract}};

assign arithmetic_result =
    a + b_modified + subtract;

// Comparison results
wire signed_less;
wire unsigned_less;

assign signed_less =
    (a[WIDTH-1] != b[WIDTH-1]) ?
    a[WIDTH-1] :
    arithmetic_result[WIDTH-1];

assign unsigned_less =
    (a < b);

// ALU operation selection
always @(*) begin
    case (alu_ctrl)

        4'b0000:
            alu_out = arithmetic_result; // ADD

        4'b0001:
            alu_out = arithmetic_result; // SUB

        4'b0010:
            alu_out = a & b; // AND

        4'b0011:
            alu_out = a | b; // OR

        4'b0100:
            alu_out = a ^ b; // XOR

        4'b0101:
            alu_out = {{(WIDTH-1){1'b0}},
                       signed_less}; // SLT

        4'b0110:
            alu_out = a << b[4:0]; // SLL

        4'b0111:
            alu_out = {{(WIDTH-1){1'b0}},
                       unsigned_less}; // SLTU

        4'b1000:
            alu_out = a >> b[4:0]; // SRL

        4'b1001:
            alu_out = $signed(a) >>> b[4:0]; // SRA

        default:
            alu_out = {WIDTH{1'b0}};

    endcase
end

assign zero = (alu_out == 0);

endmodule
