// datapath.v - 5-stage pipelined RISC-V datapath

module datapath (
    input clk, reset,

    input [31:0] InstrF,
    output [31:0] PCF,
    output [31:0] InstrD,

    input [1:0] ResultSrcD,
    input ALUSrcD, RegWriteD, MemWriteD,
    input [2:0] ImmSrcD,
    input [3:0] ALUControlD,
    input BranchD, JumpD, JalrD, AUIPCD,

    input [31:0] ReadDataM,

    output [31:0] Mem_WrAddr, Mem_WrData,
    output MemWriteM,
    output [2:0] funct3M,

    output [31:0] ResultW,
    output [31:0] PCW, ALUResultW, WriteDataW
);

// ==================================================
// FETCH STAGE
// ==================================================

wire [31:0] PCNextF, PCPlus4F;
wire [31:0] PCD, PCPlus4D;
wire [31:0] PCTargetE, PCJalrE;

wire StallF, StallD, FlushD, FlushE;
wire PCSrcE;
wire JalrE;

assign PCNextF = PCSrcE ?
                 (JalrE ? PCJalrE : PCTargetE) :
                 PCPlus4F;

reset_ff #(32) pcreg (
    clk, reset, StallF, PCNextF, PCF
);

adder pcadd4 (
    PCF, 32'd4, PCPlus4F
);

// ==================================================
// FETCH / DECODE PIPELINE REGISTER
// ==================================================

pl_reg_fd plfd (
    clk,
    StallD,
    FlushD | reset,
    InstrF,
    PCF,
    PCPlus4F,
    InstrD,
    PCD,
    PCPlus4D
);

// ==================================================
// DECODE STAGE
// ==================================================

wire [31:0] RD1D, RD2D, ImmExtD;

wire [4:0] Rs1D, Rs2D, RdD;

assign Rs1D = InstrD[19:15];
assign Rs2D = InstrD[24:20];
assign RdD  = InstrD[11:7];

wire RegWriteW;
wire [4:0] RdW;

reg_file rf (
    clk,
    RegWriteW,
    Rs1D,
    Rs2D,
    RdW,
    ResultW,
    RD1D,
    RD2D
);

imm_extend ext (
    InstrD[31:7],
    ImmSrcD,
    ImmExtD
);

// ==================================================
// DECODE / EXECUTE PIPELINE REGISTER
// ==================================================

wire [31:0] RD1E, RD2E;
wire [31:0] PCE, PCPlus4E, ImmExtE;

wire [4:0] Rs1E, Rs2E, RdE;

wire RegWriteE, MemWriteE, ALUSrcE;
wire BranchE, JumpE,  AUIPCE;

wire [1:0] ResultSrcE;
wire [3:0] ALUControlE;
wire [2:0] funct3E;

pl_reg_de plde (
    .clk(clk),
    .reset(reset),
    .clr(FlushE),

    .RD1D(RD1D),
    .RD2D(RD2D),
    .PCD(PCD),
    .PCPlus4D(PCPlus4D),
    .ImmExtD(ImmExtD),

    .Rs1D(Rs1D),
    .Rs2D(Rs2D),
    .RdD(RdD),

    .RegWriteD(RegWriteD),
    .MemWriteD(MemWriteD),
    .ALUSrcD(ALUSrcD),

    .BranchD(BranchD),
    .JumpD(JumpD),
    .JalrD(JalrD),
    .AUIPCD(AUIPCD),

    .ResultSrcD(ResultSrcD),
    .ALUControlD(ALUControlD),
    .funct3D(InstrD[14:12]),

    .RD1E(RD1E),
    .RD2E(RD2E),
    .PCE(PCE),
    .PCPlus4E(PCPlus4E),
    .ImmExtE(ImmExtE),

    .Rs1E(Rs1E),
    .Rs2E(Rs2E),
    .RdE(RdE),

    .RegWriteE(RegWriteE),
    .MemWriteE(MemWriteE),
    .ALUSrcE(ALUSrcE),

    .BranchE(BranchE),
    .JumpE(JumpE),
    .JalrE(JalrE),
    .AUIPCE(AUIPCE),

    .ResultSrcE(ResultSrcE),
    .ALUControlE(ALUControlE),
    .funct3E(funct3E)
);

// ==================================================
// EXECUTE STAGE
// ==================================================

wire [1:0] ForwardAE, ForwardBE;

wire [31:0] SrcAE, WriteDataE, SrcBE;
wire [31:0] ALUResultE;

wire ZeroE;


wire [31:0] ALUResultM;
wire [31:0] ForwardDataM;

assign ForwardDataM = ALUResultM;

// Forwarding for operand A
assign SrcAE =
    (ForwardAE == 2'b10) ? ForwardDataM :
    (ForwardAE == 2'b01) ? ResultW :
                           RD1E;

// Forwarding for operand B
assign WriteDataE =
    (ForwardBE == 2'b10) ? ForwardDataM :
    (ForwardBE == 2'b01) ? ResultW :
                           RD2E;

// ALU source selection
assign SrcBE = ALUSrcE ? ImmExtE : WriteDataE;

alu alu_inst (
    SrcAE,
    SrcBE,
    ALUControlE,
    ALUResultE,
    ZeroE
);

// Branch decision
// Branch comparison logic
wire EqualE;
wire LessThanE;
wire LessThanUnsignedE;

assign EqualE = (SrcAE == WriteDataE);

assign LessThanE =
    ($signed(SrcAE) < $signed(WriteDataE));

assign LessThanUnsignedE =
    (SrcAE < WriteDataE);

// Branch decision
reg TakeBranchE;

always @(*) begin
    case (funct3E)
        3'b000: TakeBranchE = EqualE;             // BEQ
        3'b001: TakeBranchE = !EqualE;            // BNE
        3'b100: TakeBranchE = LessThanE;          // BLT
        3'b101: TakeBranchE = !LessThanE;         // BGE
        3'b110: TakeBranchE = LessThanUnsignedE;  // BLTU
        3'b111: TakeBranchE = !LessThanUnsignedE; // BGEU
        default: TakeBranchE = 1'b0;
    endcase
end

// Branch target
assign PCTargetE = PCE + ImmExtE;

// JALR target
assign PCJalrE = (SrcAE + ImmExtE) & 32'hFFFFFFFE;

// Branch or jump decision
assign PCSrcE =
    (BranchE && TakeBranchE) ||
    JumpE ||
    JalrE;

// LUI / AUIPC result
wire [31:0] AuiPCE;

assign AuiPCE = AUIPCE ?
                (PCE + ImmExtE) :
                ImmExtE;

// ==================================================
// EXECUTE / MEMORY PIPELINE REGISTER
// ==================================================

wire [31:0] WriteDataM;
wire [31:0] PCPlus4M, AuiPCM, PCM;

wire [4:0] RdM;

wire RegWriteM;
wire [1:0] ResultSrcM;

pl_reg_em plem (
    .clk(clk),
    .clr(reset),

    .ALUResultE(ALUResultE),
    .WriteDataE(WriteDataE),
    .PCPlus4E(PCPlus4E),
    .AuiPCE(AuiPCE),
    .PCE(PCE),
    .RdE(RdE),

    .RegWriteE(RegWriteE),
    .MemWriteE(MemWriteE),
    .ResultSrcE(ResultSrcE),
    .funct3E(funct3E),

    .ALUResultM(ALUResultM),
    .WriteDataM(WriteDataM),
    .PCPlus4M(PCPlus4M),
    .AuiPCM(AuiPCM),
    .PCM(PCM),
    .RdM(RdM),

    .RegWriteM(RegWriteM),
    .MemWriteM(MemWriteM),
    .ResultSrcM(ResultSrcM),
    .funct3M(funct3M)
);

// ==================================================
// MEMORY STAGE
// ==================================================

assign Mem_WrAddr = ALUResultM;
assign Mem_WrData = WriteDataM;

// ==================================================
// MEMORY / WRITEBACK PIPELINE REGISTER
// ==================================================

wire [31:0] ReadDataW;
wire [31:0] PCPlus4W, AuiPCW;
wire [1:0] ResultSrcW;

pl_reg_mw plmw (
    .clk(clk),
    .clr(reset),

    .ALUResultM(ALUResultM),
    .ReadDataM(ReadDataM),
    .PCPlus4M(PCPlus4M),
    .AuiPCM(AuiPCM),
    .PCM(PCM),
    .WriteDataM(WriteDataM),
    .RdM(RdM),

    .RegWriteM(RegWriteM),
    .ResultSrcM(ResultSrcM),

    .ALUResultW(ALUResultW),
    .ReadDataW(ReadDataW),
    .PCPlus4W(PCPlus4W),
    .AuiPCW(AuiPCW),
    .PCW(PCW),
    .WriteDataW(WriteDataW),
    .RdW(RdW),

    .RegWriteW(RegWriteW),
    .ResultSrcW(ResultSrcW)
);

// ==================================================
// WRITEBACK STAGE
// ==================================================

mux4 #(32) resultmux (
    ALUResultW,
    ReadDataW,
    PCPlus4W,
    AuiPCW,
    ResultSrcW,
    ResultW
);

// ==================================================
// HAZARD UNIT
// ==================================================

hazard_unit hu (
    .Rs1D(Rs1D),
    .Rs2D(Rs2D),

    .Rs1E(Rs1E),
    .Rs2E(Rs2E),

    .RdE(RdE),
    .RdM(RdM),
    .RdW(RdW),

    .RegWriteM(RegWriteM),
    .RegWriteW(RegWriteW),

    .ResultSrcE(ResultSrcE),
    .PCSrcE(PCSrcE),

    .ForwardAE(ForwardAE),
    .ForwardBE(ForwardBE),

    .StallF(StallF),
    .StallD(StallD),

    .FlushD(FlushD),
    .FlushE(FlushE)
);

endmodule
