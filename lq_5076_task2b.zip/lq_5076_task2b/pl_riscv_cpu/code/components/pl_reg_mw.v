// pl_reg_mw.v - Memory to Writeback Pipeline Register

module pl_reg_mw (
    input clk,
    input clr,

    // Data from Memory stage
    input [31:0] ALUResultM,
    input [31:0] ReadDataM,
    input [31:0] PCPlus4M,
    input [31:0] AuiPCM,
    input [31:0] PCM,
    input [31:0] WriteDataM,
    input [4:0] RdM,

    // Control signals from Memory stage
    input RegWriteM,
    input [1:0] ResultSrcM,

    // Data to Writeback stage
    output reg [31:0] ALUResultW,
    output reg [31:0] ReadDataW,
    output reg [31:0] PCPlus4W,
    output reg [31:0] AuiPCW,
    output reg [31:0] PCW,
    output reg [31:0] WriteDataW,
    output reg [4:0] RdW,

    // Control signals to Writeback stage
    output reg RegWriteW,
    output reg [1:0] ResultSrcW
);

always @(posedge clk) begin

    if (clr) begin
        ALUResultW <= 0;
        ReadDataW <= 0;
        PCPlus4W <= 0;
        AuiPCW <= 0;
        PCW <= 0;
        WriteDataW <= 0;
        RdW <= 0;

        RegWriteW <= 0;
        ResultSrcW <= 0;
    end

    else begin
        ALUResultW <= ALUResultM;
        ReadDataW <= ReadDataM;
        PCPlus4W <= PCPlus4M;
        AuiPCW <= AuiPCM;
        PCW <= PCM;
        WriteDataW <= WriteDataM;
        RdW <= RdM;

        RegWriteW <= RegWriteM;
        ResultSrcW <= ResultSrcM;
    end

end

endmodule
