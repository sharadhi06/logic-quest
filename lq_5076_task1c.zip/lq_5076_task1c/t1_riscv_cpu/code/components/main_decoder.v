
// main_decoder.v - logic for main decoder

module main_decoder (
    input  [6:0] op,
    output [1:0] ResultSrc,
    output       MemWrite, Branch, ALUSrc,
    output       RegWrite, Jump, AUIPC,JALR,
    output [2:0] ImmSrc,
    output [1:0] ALUOp
);

reg [13:0] controls;

always @(*) begin
    case (op)
        // RegWrite_ImmSrc_ALUSrc_MemWrite_ResultSrc_Branch_ALUOp_Jump_AUIPC_JALR

        7'b0000011: controls = 14'b1_000_1_0_01_0_00_0_0_0; // lw
        7'b0100011: controls = 14'b0_001_1_1_00_0_00_0_0_0; // sw
        7'b0110011: controls = 14'b1_xxx_0_0_00_0_10_0_0_0; // R-type
        7'b1100011: controls = 14'b0_010_0_0_00_1_01_0_0_0; // beq
        7'b0010011: controls = 14'b1_000_1_0_00_0_10_0_0_0; // I-type
        7'b1101111: controls = 14'b1_011_0_0_10_0_00_1_0_0; // jal

        // LUI
        7'b0110111: controls = 14'b1_100_x_0_11_0_00_0_0_0;

        // AUIPC
        7'b0010111: controls = 14'b1_100_x_0_11_0_00_0_1_0;

        // JALR
        7'b1100111: controls = 14'b1_000_1_0_10_0_00_0_0_1;

        default: controls = 14'bx_xxx_x_x_xx_x_xx_x_x_x;
    endcase
end

assign {RegWrite, ImmSrc, ALUSrc, MemWrite,
        ResultSrc, Branch, ALUOp, Jump, AUIPC, JALR} = controls;
endmodule

